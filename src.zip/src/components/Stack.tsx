const stackCards = [
  { cat: "Frontend",       items: ["Next.js / React", "TypeScript", "Tailwind CSS", "Framer Motion", "Zustand"] },
  { cat: "Backend",        items: ["Node.js / Express", "Laravel / PHP", "Prisma ORM", "REST API", "NextAuth"] },
  { cat: "Database & Infra", items: ["PostgreSQL", "Supabase", "MySQL", "Vercel", "Git / GitHub"] },
  { cat: "AI & Tools",     items: ["Groq / LLaMA", "OpenAI API", "Figma / Canva", "VS Code", "Postman"] },
];

export default function Stack() {
  return (
    <section id="stack" style={{ background: "var(--army)", padding: "120px 7vw" }}>
      {/* Label */}
      <div
        className="flex items-center uppercase"
        style={{
          gap: 14,
          fontFamily: "var(--font-jetbrains), monospace",
          fontSize: "0.62rem",
          letterSpacing: "0.18em",
          color: "var(--army-pale)",
          marginBottom: 20,
        }}
      >
        <span style={{ width: 32, height: 1, background: "var(--army-pale)", display: "block" }} />
        Tech stack
      </div>

      {/* Title */}
      <h2
        className="reveal"
        style={{
          fontFamily: "var(--font-cormorant), serif",
          fontWeight: 300,
          fontSize: "clamp(2.2rem, 4vw, 3.8rem)",
          lineHeight: 1.1,
          letterSpacing: "-0.02em",
          color: "var(--cream)",
          marginBottom: 72,
        }}
      >
        Tools of the
        <br />
        <em style={{ fontStyle: "italic", color: "var(--earth-light)" }}>craft.</em>
      </h2>

      <div
        className="grid"
        style={{
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 1,
          background: "rgba(255,255,255,0.08)",
        }}
      >
        {stackCards.map((card, i) => (
          <div key={card.cat} className={`stack-card reveal rd${Math.min(i + 1, 4)}`}>
            <div
              className="uppercase"
              style={{
                fontFamily: "var(--font-jetbrains), monospace",
                fontSize: "0.58rem",
                letterSpacing: "0.14em",
                color: "var(--army-pale)",
                marginBottom: 16,
              }}
            >
              {card.cat}
            </div>
            <div className="flex flex-col" style={{ gap: 10 }}>
              {card.items.map((item) => (
                <div
                  key={item}
                  className="flex items-center"
                  style={{ gap: 12, fontSize: "0.9rem", color: "var(--cream)", fontWeight: 300 }}
                >
                  <span
                    className="rounded-full shrink-0"
                    style={{ width: 5, height: 5, background: "var(--earth-light)" }}
                  />
                  {item}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @media (max-width: 860px) {
          #stack .grid { grid-template-columns: 1fr 1fr !important; }
        }
      `}</style>
    </section>
  );
}
