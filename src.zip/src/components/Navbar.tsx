import Link from "next/link";

const navLinks = [
  { href: "#about",    label: "About" },
  { href: "#projects", label: "Projects" },
  { href: "#stack",    label: "Stack" },
  { href: "#contact",  label: "Contact" },
];

export default function Navbar() {
  return (
    <nav
      className="fixed top-0 left-0 right-0 z-[100] flex items-center justify-between"
      style={{
        padding: "28px 7vw",
        background: "linear-gradient(to bottom, rgba(247,243,233,0.96), transparent)",
        backdropFilter: "blur(6px)",
      }}
    >
      <Link href="#hero" className="no-underline">
        <span
          style={{
            fontFamily: "var(--font-cormorant), serif",
            fontWeight: 600,
            fontSize: "1.25rem",
            letterSpacing: "0.06em",
            color: "var(--army)",
          }}
        >
          Muhammad
          <em style={{ fontStyle: "italic", fontWeight: 300, color: "var(--earth-light)" }}>
            Fadil
          </em>
        </span>
      </Link>

      <ul className="hidden md:flex gap-10 list-none">
        {navLinks.map((link) => (
          <li key={link.href}>
            <Link
              href={link.href}
              className="nav-link no-underline uppercase"
              style={{
                fontFamily: "var(--font-jetbrains), monospace",
                fontSize: "0.68rem",
                color: "var(--text-muted)",
                letterSpacing: "0.12em",
                transition: "color 0.2s",
              }}
            >
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
