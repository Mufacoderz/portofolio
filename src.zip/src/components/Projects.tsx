const projects = [
  {
    num: "01", name: "Dev", nameItalic: "Note",
    desc: "Developer snippet manager with public explore page, syntax highlighting, collections & smart filtering.",
    tags: ["Next.js 15", "TypeScript", "Prisma", "Supabase", "Framer Motion"],
    href: "#",
  },
  {
    num: "02", name: "Mufadz", nameItalic: "App",
    desc: "Islamic utility app — Quran, prayer schedules, doa, and AI chatbot powered by Groq/LLaMA.",
    tags: ["Next.js", "Groq AI", "Laravel", "MySQL"],
    href: "#",
  },
  {
    num: "03", name: "Daily", nameItalic: "Fit",
    desc: "Fitness tracker with workout studio, exercise plans, daily checklists, and stats visualization.",
    tags: ["Next.js", "App Router", "Tailwind", "Charts"],
    href: "#",
  },
  {
    num: "04", name: "Mufine", nameItalic: "Wallet",
    desc: "Personal finance tracker with goals, CSV/PDF export, and visual charts. Built with React + Vite.",
    tags: ["React", "Vite", "Express", "Charts"],
    href: "#",
  },
  {
    num: "05", name: "TechGear", nameItalic: "Store",
    desc: "E-commerce storefront for tech products with cart, orders, and admin dashboard.",
    tags: ["React", "Vite", "Express", "MySQL"],
    href: "#",
  },
];

export default function Projects() {
  return (
    <section id="projects" style={{ background: "var(--parchment)", padding: "120px 7vw" }}>
      {/* Label */}
      <div
        className="flex items-center uppercase"
        style={{
          gap: 14,
          fontFamily: "var(--font-jetbrains), monospace",
          fontSize: "0.62rem",
          letterSpacing: "0.18em",
          color: "var(--army-light)",
          marginBottom: 20,
        }}
      >
        <span style={{ width: 32, height: 1, background: "var(--army-light)", display: "block" }} />
        Selected work
      </div>

      {/* Title */}
      <h2
        className="reveal"
        style={{
          fontFamily: "var(--font-cormorant), serif",
          fontWeight: 300,
          fontSize: "clamp(2.2rem, 4vw, 3.8rem)",
          lineHeight: 1.1,
          letterSpacing: "-0.02em",
          color: "var(--army)",
          marginBottom: 72,
        }}
      >
        Things I&apos;ve built
        <br />
        <em style={{ fontStyle: "italic", color: "var(--earth-light)" }}>and shipped.</em>
      </h2>

      <div className="flex flex-col" style={{ gap: 2 }}>
        {projects.map((p, i) => (
          <a
            key={p.num}
            href={p.href}
            className={`proj-row reveal rd${Math.min(i + 1, 4)}`}
          >
            <div
              className="proj-num"
              style={{
                fontFamily: "var(--font-cormorant), serif",
                fontSize: "2rem",
                fontWeight: 300,
                color: "var(--cream-deep)",
                lineHeight: 1,
                position: "relative",
                zIndex: 1,
              }}
            >
              {p.num}
            </div>

            <div style={{ position: "relative", zIndex: 1 }}>
              <div
                style={{
                  fontFamily: "var(--font-cormorant), serif",
                  fontWeight: 600,
                  fontSize: "1.6rem",
                  letterSpacing: "-0.01em",
                  color: "var(--army)",
                  marginBottom: 6,
                }}
              >
                {p.name}
                <em style={{ fontStyle: "italic", fontWeight: 300, color: "var(--earth-light)" }}>
                  {p.nameItalic}
                </em>
              </div>
              <p style={{ fontSize: "0.88rem", color: "var(--text-muted)", lineHeight: 1.7 }}>
                {p.desc}
              </p>
            </div>

            <div className="flex flex-wrap" style={{ gap: 8, position: "relative", zIndex: 1 }}>
              {p.tags.map((tag) => (
                <span
                  key={tag}
                  style={{
                    fontFamily: "var(--font-jetbrains), monospace",
                    fontSize: "0.58rem",
                    padding: "4px 10px",
                    border: "1px solid var(--border-strong)",
                    color: "var(--text-muted)",
                    letterSpacing: "0.06em",
                    background: "transparent",
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>

            <div
              className="proj-arrow"
              style={{
                fontSize: "1.4rem",
                color: "var(--border-strong)",
                position: "relative",
                zIndex: 1,
                transition: "color 0.2s, transform 0.2s",
              }}
            >
              →
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}
