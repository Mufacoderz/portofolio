const contactLinks = [
  { label: "Email",     val: "hello@fadil.dev",    href: "mailto:hello@fadil.dev" },
  { label: "GitHub",    val: "@Mufacoderz",         href: "https://github.com/Mufacoderz" },
  { label: "LinkedIn",  val: "Muhammad Fadil",      href: "#" },
  { label: "Portfolio", val: "fadil.dev",           href: "#" },
];

export default function Contact() {
  return (
    <section id="contact" style={{ background: "var(--cream-dim)", padding: "120px 7vw" }}>
      {/* Label */}
      <div
        className="flex items-center uppercase"
        style={{
          gap: 14,
          fontFamily: "var(--font-jetbrains), monospace",
          fontSize: "0.62rem",
          letterSpacing: "0.18em",
          color: "var(--army-light)",
          marginBottom: 20,
        }}
      >
        <span style={{ width: 32, height: 1, background: "var(--army-light)", display: "block" }} />
        Let&apos;s talk
      </div>

      <div
        className="grid items-center"
        style={{ gridTemplateColumns: "1fr 1fr", gap: 100 }}
      >
        {/* Left */}
        <div className="reveal">
          <h2
            style={{
              fontFamily: "var(--font-cormorant), serif",
              fontWeight: 300,
              fontSize: "clamp(2.8rem, 5vw, 5rem)",
              lineHeight: 1.0,
              letterSpacing: "-0.03em",
              color: "var(--army)",
            }}
          >
            Got an idea?
            <em style={{ fontStyle: "italic", color: "var(--earth-light)", display: "block" }}>
              Let&apos;s build it.
            </em>
          </h2>
          <p style={{ marginTop: 24, fontSize: "0.95rem", color: "var(--text-muted)", lineHeight: 1.9, maxWidth: 380 }}>
            Open for freelance projects, startup collaborations, or just a good
            conversation about products and code.
          </p>
        </div>

        {/* Right */}
        <div className="reveal rd2 flex flex-col" style={{ gap: 2 }}>
          {contactLinks.map((item) => (
            <a key={item.label} href={item.href} className="contact-item">
              <div className="flex flex-col" style={{ gap: 4 }}>
                <span
                  className="uppercase"
                  style={{
                    fontFamily: "var(--font-jetbrains), monospace",
                    fontSize: "0.6rem",
                    letterSpacing: "0.12em",
                    color: "var(--text-muted)",
                  }}
                >
                  {item.label}
                </span>
                <span style={{ fontSize: "0.95rem", color: "var(--army)", fontWeight: 400 }}>
                  {item.val}
                </span>
              </div>
              <span
                className="ci-arrow"
                style={{ color: "var(--army-pale)", fontSize: "1rem", transition: "transform 0.2s, color 0.2s" }}
              >
                →
              </span>
            </a>
          ))}
        </div>
      </div>

      <style>{`
        @media (max-width: 860px) {
          #contact .grid { grid-template-columns: 1fr !important; gap: 48px !important; }
        }
      `}</style>
    </section>
  );
}
