import Image from "next/image";

const asideItems = [
  { key: "Location",  val: "East Kalimantan, Indonesia" },
  { key: "Status",    val: "Available for work" },
  { key: "Focus",     val: "Fullstack · AI · SaaS" },
  { key: "Education", val: "Information Systems, S1" },
  { key: "GitHub",    val: "@Mufacoderz" },
];

export default function About() {
  return (
    <section id="about" style={{ background: "var(--cream)", padding: "120px 7vw" }}>
      {/* Label */}
      <div
        className="flex items-center uppercase"
        style={{
          gap: 14,
          fontFamily: "var(--font-jetbrains), monospace",
          fontSize: "0.62rem",
          letterSpacing: "0.18em",
          color: "var(--army-light)",
          marginBottom: 20,
        }}
      >
        <span style={{ width: 32, height: 1, background: "var(--army-light)", display: "block" }} />
        About me
      </div>

      {/* Title */}
      <h2
        className="reveal"
        style={{
          fontFamily: "var(--font-cormorant), serif",
          fontWeight: 300,
          fontSize: "clamp(2.2rem, 4vw, 3.8rem)",
          lineHeight: 1.1,
          letterSpacing: "-0.02em",
          color: "var(--army)",
          marginBottom: 72,
        }}
      >
        Code is craft.
        <br />
        <em style={{ fontStyle: "italic", color: "var(--earth-light)" }}>
          Products are purpose.
        </em>
      </h2>

      {/* Grid */}
      <div
        className="grid items-start"
        style={{ gridTemplateColumns: "3fr 2fr", gap: 100 }}
      >
        {/* Kiri: foto + body text */}
        <div className="reveal rd1 flex flex-col" style={{ gap: 32 }}>
          {/* Foto */}
          <div
            className="relative overflow-hidden"
            style={{
              width: "100%",
              maxWidth: 360,
              height: 360,
              border: "1px solid var(--border)",
              background: "var(--cream-dim)",
            }}
          >
            <Image
              src="/me.png"
              alt="Fadil"
              fill
              className="object-cover object-top"
              priority
            />
            {/* Gradient overlay */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{ background: "linear-gradient(to top, rgba(42,51,36,0.55) 0%, transparent 50%)" }}
            />
            {/* Badge */}
            <div className="absolute" style={{ bottom: 14, left: 12, right: 12 }}>
              <span
                className="block uppercase"
                style={{
                  fontFamily: "var(--font-jetbrains), monospace",
                  fontSize: "0.5rem",
                  letterSpacing: "0.12em",
                  color: "rgba(240,234,216,0.65)",
                  marginBottom: 3,
                }}
              >
                Fadil · developer
              </span>
              <span
                className="block italic"
                style={{
                  fontFamily: "var(--font-cormorant), serif",
                  fontSize: "0.88rem",
                  color: "var(--cream)",
                  lineHeight: 1.2,
                }}
              >
                East Kalimantan, ID
              </span>
            </div>
          </div>

          {/* Body text */}
          <div className="about-body">
            <p>
              I&apos;m <strong>Fadil</strong> — a self-taught fullstack developer from
              East Kalimantan, Indonesia. Currently studying Information Systems
              while building real products on the side.
            </p>
            <p>
              My philosophy is{" "}
              <em>product-first</em>: every line of code serves a real need.
              I&apos;m not interested in building things that collect dust — I want
              to ship tools that developers and people actually use.
            </p>
            <p>
              Currently exploring the intersection of{" "}
              <strong>AI, Web3, and SaaS</strong>. Long-term goal: founding
              engineer at an early-stage startup, or building my own indie products.
            </p>
          </div>
        </div>

        {/* Kanan: aside */}
        <div className="reveal rd2 flex flex-col" style={{ gap: 2 }}>
          {asideItems.map((item) => (
            <div key={item.key} className="aside-item">
              <div
                className="uppercase"
                style={{
                  fontFamily: "var(--font-jetbrains), monospace",
                  fontSize: "0.6rem",
                  letterSpacing: "0.12em",
                  color: "var(--text-muted)",
                  marginBottom: 6,
                }}
              >
                {item.key}
              </div>
              <div style={{ fontSize: "0.95rem", color: "var(--army)", fontWeight: 400 }}>
                {item.val}
              </div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        .about-body p {
          font-size: 1.05rem;
          color: var(--text-body);
          line-height: 2;
          margin-bottom: 24px;
        }
        .about-body p strong { color: var(--army); font-weight: 500; }
        .about-body p em {
          font-family: var(--font-cormorant), serif;
          font-style: italic;
          color: var(--earth);
          font-size: 1.1em;
        }
        @media (max-width: 860px) {
          #about .grid { grid-template-columns: 1fr !important; gap: 48px !important; }
        }
      `}</style>
    </section>
  );
}
