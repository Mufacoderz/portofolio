import Link from "next/link";

const stats = [
  { big: "1.5+", title: "Years of building", sub: "Self-taught · Fullstack" },
  { big: "5+",   title: "Products shipped",  sub: "Web apps · Tools · SaaS" },
  { big: "3",    title: "Active projects",   sub: "DevNote · Mufadz · Mufit" },
];

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative overflow-hidden grid items-center"
      style={{
        minHeight: "100vh",
        padding: "0 7vw",
        gridTemplateColumns: "1fr 1fr",
        gap: 80,
      }}
    >
      {/* Deco line */}
      <div
        className="absolute top-0 left-1/2 w-px h-full hidden md:block"
        style={{ background: "linear-gradient(to bottom, transparent, var(--border) 25%, var(--border) 75%, transparent)" }}
      />
      {/* Deco circles */}
      <div
        className="absolute rounded-full pointer-events-none opacity-50 hidden md:block"
        style={{ top: "50%", right: "8%", transform: "translateY(-50%)", width: 420, height: 420, border: "1px solid var(--border)" }}
      />
      <div
        className="absolute rounded-full pointer-events-none hidden md:block"
        style={{ top: "50%", right: "8%", transform: "translateY(-50%)", width: 300, height: 300, border: "1px solid var(--border-strong)" }}
      />

      {/* Left — text */}
      <div className="relative" style={{ zIndex: 2 }}>
        <div
          className="animate-fade-up-1 flex items-center uppercase"
          style={{
            gap: 12,
            fontFamily: "var(--font-jetbrains), monospace",
            fontSize: "0.65rem",
            letterSpacing: "0.18em",
            color: "var(--army-light)",
            marginBottom: 36,
          }}
        >
          <span
            className="rounded-full shrink-0"
            style={{ width: 6, height: 6, background: "var(--earth-light)" }}
          />
          Open to opportunities
        </div>

        <h1
          className="animate-fade-up-2"
          style={{
            fontFamily: "var(--font-cormorant), serif",
            fontWeight: 300,
            fontSize: "clamp(3.5rem, 6.5vw, 6rem)",
            lineHeight: 1.0,
            letterSpacing: "-0.02em",
            color: "var(--army)",
          }}
        >
          Fullstack
          <em style={{ fontStyle: "italic", color: "var(--earth-light)", display: "block" }}>
            Developer
          </em>
          <strong style={{ fontWeight: 600, color: "var(--moss)" }}>&amp; Builder.</strong>
        </h1>

        <p
          className="animate-fade-up-3"
          style={{
            marginTop: 32,
            fontSize: "1rem",
            fontWeight: 300,
            color: "var(--text-muted)",
            maxWidth: 420,
            lineHeight: 1.9,
          }}
        >
          Crafting purposeful digital products — from developer tools to
          AI-powered apps. Based in East Kalimantan, Indonesia.
        </p>

        <div className="animate-fade-up-4 flex items-center" style={{ marginTop: 48, gap: 16 }}>
          <Link href="#projects" className="btn-earth">View Work →</Link>
          <Link href="#contact" className="btn-ghost">Get in touch</Link>
        </div>
      </div>

      {/* Right — stats */}
      <div
        className="animate-fade-up-3 flex flex-col"
        style={{ position: "relative", zIndex: 2, gap: 2 }}
      >
        {stats.map((s) => (
          <div key={s.big} className="hero-stat">
            <div
              style={{
                fontFamily: "var(--font-cormorant), serif",
                fontWeight: 600,
                fontSize: "2.8rem",
                color: "var(--army)",
                lineHeight: 1,
                flexShrink: 0,
              }}
            >
              {s.big}
            </div>
            <div>
              <div style={{ fontWeight: 400, fontSize: "0.9rem", color: "var(--text-body)" }}>
                {s.title}
              </div>
              <div
                style={{
                  fontFamily: "var(--font-jetbrains), monospace",
                  fontSize: "0.62rem",
                  color: "var(--text-muted)",
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                }}
              >
                {s.sub}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
