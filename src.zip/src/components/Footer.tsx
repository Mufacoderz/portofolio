export default function Footer() {
  return (
    <footer
      className="flex items-center justify-between"
      style={{ background: "var(--moss)", padding: "28px 7vw" }}
    >
      <span
        style={{
          fontFamily: "var(--font-cormorant), serif",
          fontSize: "1rem",
          fontWeight: 600,
          color: "var(--cream-dim)",
          letterSpacing: "0.06em",
        }}
      >
        Muhammad{" "}
        <em style={{ fontStyle: "italic", fontWeight: 300, color: "var(--earth-light)" }}>
          Fadil
        </em>
      </span>
      <span
        style={{
          fontFamily: "var(--font-jetbrains), monospace",
          fontSize: "0.62rem",
          color: "var(--army-pale)",
          letterSpacing: "0.08em",
        }}
      >
        © 2025 · Built with Next.js · Vercel
      </span>
    </footer>
  );
}
