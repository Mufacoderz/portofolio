"use client";

import { useEffect } from "react";

export default function ScrollReveal() {
    useEffect(() => {
        const obs = new IntersectionObserver(
            (entries) => {
                entries.forEach((e) => {
                    if (e.isIntersecting) {
                        e.target.classList.add("on");
                        obs.unobserve(e.target);
                    }
                });
            },
            { threshold: 0.1 }
        );

        document.querySelectorAll(".reveal").forEach((el) => obs.observe(el));

        return () => obs.disconnect();
    }, []);

    return null;
}